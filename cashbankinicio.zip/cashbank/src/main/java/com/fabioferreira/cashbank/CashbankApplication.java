package com.fabioferreira.cashbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CashbankApplication {

	public static void main(String[] args) {
		SpringApplication.run(CashbankApplication.class, args);
	}

}
